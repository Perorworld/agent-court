# Agent Court Demo

A sample deliverable used by the Internet Court x GenLayer x LayerZero demo.

## Features
1. Cross-chain escrow locking over LayerZero v2
2. AI-native dispute resolution on GenLayer
3. Agent skill file for Eliza / LangChain / Subzero

## Live demo
https://example.com/agent-court-demo

---
name: judged-settlement-room
version: 1.0.0
description: >
  Pool funds in a Yellow settlement room, and when the parties disagree, let
  GenLayer validators rule on the deliverable and settle the resulting split
  through Yellow. For agent frameworks (Eliza, LangChain, Claude Code, Codex).
composes_with:
  - yellow-settlement-room   # npx skills add internet-court/internet-court-skill
requires_env:
  - ADJUDICATOR_ADDRESS      # deployed AgentCourtAdjudicator on GenLayer
  - BUYER_PK
  - SELLER_PK
  - COURT_PK
  - YELLOW_CHAIN_ID
  - YELLOW_RPC_URL
requires_bins: [node, npx]
---

# Judged Settlement Room (Internet Court × GenLayer × Yellow)

## When to use
| User intent | Step |
|---|---|
| "set up a shared escrow", "pool funds with another agent" | 1 Open room |
| "here is my finished work" | 2 Submit deliverable |
| "I reject this", "open a dispute" | 3 Ask GenLayer to rule |
| "pay out the ruling", "close the room" | 4 Settle on Yellow |

## Hard rules
1. Never move funds without the user confirming amount, asset and both counterparties.
2. Yellow never funds accounts for you. Check the depositor's balance first and stop if it is short.
3. Deliverable URLs must be public. GenLayer validators cannot open login-gated pages.
4. State the trust boundary before any value moves (below).
5. Report the ruling exactly as returned: `seller_percent`, `confidence`, `reason`.

## Steps

### 1. Open the room (Yellow)
Follow Yellow's `yellow-settlement-room` skill: create an app session with three participants
(buyer, seller, court), weights `1/1/1`, quorum `2`, then the buyer deposits.
The reference implementation is `scripts/yellow_settlement.ts` (`liveRoom`).

### 2. Seller submits the deliverable
Record the public URL and the plain-language acceptance rules both sides agreed.
Write rules as checkable statements ("names the project", "lists 3 features", "links a live demo").

### 3. Ask GenLayer to rule
```bash
genlayer network set studionet
genlayer write $ADJUDICATOR_ADDRESS resolve_dispute --args "$DELIVERABLE_URL" "$SPEC_RULES"
genlayer call  $ADJUDICATOR_ADDRESS get_case_count
genlayer call  $ADJUDICATOR_ADDRESS get_case --args <case_id>
```
Wait for `ACCEPTED` (30–120 s). Result:
```json
{"verdict":"SPLIT","seller_percent":70,"confidence":88,"reason":"Two of three rules met."}
```
`seller_percent` is the seller's share of the escrow: `100` pay seller, `0` refund buyer, otherwise a split.

### 4. Settle on Yellow
Compute `sellerAmount = amount × seller_percent / 100`, `buyerAmount = amount − sellerAmount`.
Run an `Operate` update restating the non-zero allocations, signed by the court and the favoured
side (seller if `seller_percent ≥ 50`, else buyer), then a `Close` update restating the same
allocations. Do not close while a dispute is unresolved.

One command that runs the whole flow:
```bash
npm run demo        # live if BUYER_PK/SELLER_PK/COURT_PK are set, otherwise dry
```

## Trust boundary (say this to the user)
- No agent can change another's allocation without signatures meeting quorum.
- The **court key** is a relayer: it signs what GenLayer decided. Yellow does not read GenLayer natively.
  With quorum 2 of 3, the court plus one party can settle without the other. Use quorum 3 (unanimous)
  if the parties would rather keep a veto.
- The Yellow node is trusted for liveness. If it will not co-sign a release, funds stay in the session.
- The deposit is the most any depositor can lose.

## Errors
| Error | Meaning / fix |
|---|---|
| balance shortfall | Buyer lacks funds at Yellow — fund first, do not retry |
| `no channel state to advance` | Depositor account not funded at Yellow |
| version mismatch | Re-read `session.version`, re-sign, retry |
| `FETCH_ERROR status=…` in reason | URL unreachable → ruling will favour the buyer |

# { "Depends": "py-genlayer:1jb45aa8ynh2a9c9xn3b7qqh8sm5q93hwfp7jqmwsfhh8jpz09h6" }

import json
import re

from genlayer import *

MAX_PROOF_CHARS = 6000


def normalize(text: str) -> str:
    """Collapse whitespace and cap length so every validator sees identical evidence."""
    return re.sub(r"\s+", " ", text).strip()[:MAX_PROOF_CHARS]


def verdict_label(seller_percent: int) -> str:
    if seller_percent >= 100:
        return "PAY_SELLER"
    if seller_percent <= 0:
        return "REFUND_BUYER"
    return "SPLIT"


def parse_ruling(raw: str) -> dict:
    """Parse the LLM output. Unusable output falls back to a full buyer refund (fail-safe)."""
    fail_safe = {
        "verdict": "REFUND_BUYER",
        "seller_percent": 0,
        "confidence": 0,
        "reason": "Unparseable evaluation; defaulting to buyer refund.",
    }
    match = re.search(r"\{.*\}", raw, re.DOTALL)
    try:
        data = json.loads(match.group(0)) if match else {}
        percent = max(0, min(100, int(data["seller_percent"])))
    except Exception:
        return fail_safe
    try:
        confidence = max(0, min(100, int(data.get("confidence", 0))))
    except Exception:
        confidence = 0
    return {
        "verdict": verdict_label(percent),
        "seller_percent": percent,
        "confidence": confidence,
        "reason": str(data.get("reason", "")).strip()[:400],
    }


class AgentCourtAdjudicator(gl.Contract):
    owner: Address
    case_count: u256
    cases: TreeMap[u256, str]

    def __init__(self):
        self.owner = gl.message.sender_address
        self.case_count = u256(0)

    @gl.public.write
    def resolve_dispute(self, deliverable_url: str, spec_rules: str) -> str:
        """Rule on a disputed deliverable. Returns JSON:
        {"verdict": "PAY_SELLER"|"REFUND_BUYER"|"SPLIT", "seller_percent": int,
         "confidence": int, "reason": str}"""
        if not deliverable_url.startswith(("http://", "https://")):
            raise Exception("deliverable_url must be a public http(s) URL")
        if len(spec_rules.strip()) == 0:
            raise Exception("spec_rules must not be empty")

        # Evidence: every validator must fetch identical, normalized proof (strict_eq)
        def fetch_proof() -> str:
            response = gl.nondet.web.get(deliverable_url)
            if response.status >= 400:
                return "FETCH_ERROR status=" + str(response.status)
            return normalize(response.body.decode("utf-8", errors="replace"))

        proof = gl.eq_principle.strict_eq(fetch_proof)

        prompt = f"""You are an impartial arbitrator deciding how escrowed funds should be split.

ACCEPTANCE RULES:
{spec_rules}

DELIVERABLE EVIDENCE (from {deliverable_url}):
\"\"\"{proof}\"\"\"

Decide what share of the escrow the seller has earned:
- 100 if the evidence satisfies ALL rules.
- 0 if the evidence is missing, unreachable, or satisfies none of the rules.
- Otherwise a number between 1 and 99, roughly proportional to how many rules are satisfied.

Respond with ONLY a JSON object, no markdown:
{{"seller_percent": <integer 0-100>, "confidence": <integer 0-100>, "reason": "<one or two sentences>"}}"""

        # LLM judgment: validators re-run it and compare (Optimistic Democracy)
        def judge() -> str:
            raw = gl.nondet.exec_prompt(prompt)
            return json.dumps(parse_ruling(raw), sort_keys=True)

        result_json = gl.eq_principle.prompt_comparative(
            judge,
            "seller_percent may differ by at most 10 points. Confidence may differ by at most 10 points. Reason may differ in wording but not meaning.",
        )
        result = json.loads(result_json)

        case_id = self.case_count
        record = {
            "case_id": int(case_id),
            "requester": str(gl.message.sender_address),
            "deliverable_url": deliverable_url,
            "spec_rules": spec_rules,
            "verdict": result["verdict"],
            "seller_percent": result["seller_percent"],
            "confidence": result["confidence"],
            "reason": result["reason"],
        }
        self.cases[case_id] = json.dumps(record, sort_keys=True)
        self.case_count = u256(int(case_id) + 1)
        return result_json

    @gl.public.view
    def get_case(self, case_id: int) -> str:
        key = u256(case_id)
        if key not in self.cases:
            return ""
        return self.cases[key]

    @gl.public.view
    def get_case_count(self) -> int:
        return int(self.case_count)

    @gl.public.view
    def get_owner(self) -> str:
        return str(self.owner)
